package test;

import java.util.Scanner;

public class Permutation {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		String input ="";
		System.out.println("Please Enter the input ");
		input = sc.nextLine();
		System.out.println("User Input : "+ input);

	}
	
	private static String permutationChk(String s1,String output) {
		
		for(int i=0;i<s1.length();i++) {
			
		}
		return "";
	}

}
